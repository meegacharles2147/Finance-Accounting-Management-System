# LedgerAI — Finance & Accounting Management System

A Python + Streamlit starter application for finance operations, featuring transaction management, financial summaries, CSV reports and GenAI invoice extraction using an OpenAI-compatible vision model.

## Features

- Dashboard with income, expenses, net profit and activity summary
- Add, search and export income/expense transactions
- Upload invoice images (PNG, JPG, WEBP)
- Extract vendor, invoice number, dates, subtotal, tax and total with a vision LLM
- Review extracted fields before saving
- Financial report and CSV download

## Tech stack

- Python
- Streamlit
- OpenAI Python SDK (OpenAI-compatible LLM API)
- Pandas

## Run locally

1. Install Python 3.10 or newer.
2. Extract this project folder.
3. Open a terminal inside the folder.
4. Create and activate a virtual environment (recommended):

   **Windows**
   ```powershell
   py -m venv .venv
   .venv\Scripts\activate
   ```

   **macOS/Linux**
   ```bash
   python3 -m venv .venv
   source .venv/bin/activate
   ```

5. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
6. Copy `.env.example` to `.env` and add your API key. The app can be explored without a key; AI extraction will show a setup message until configured.
7. Start the app:
   ```bash
   streamlit run app.py
   ```

## Deploy / upload to GitHub

- Create a new GitHub repository.
- Upload the contents of this folder (not the ZIP file alone).
- Do **not** upload `.env` or expose your API key.
- For Streamlit Community Cloud, choose this repository, set the main file to `app.py`, and add `OPENAI_API_KEY` and `OPENAI_MODEL` in the app's Secrets settings.

Example Streamlit secrets:
```toml
OPENAI_API_KEY = "your_real_key"
OPENAI_MODEL = "gpt-4o-mini"
```

## Important notes

- Invoice extraction currently accepts image files only. PDF parsing is not included in this starter.
- LLM output is a draft extraction. Always verify the values against the original invoice before saving or using them for accounting.
- Data is stored in Streamlit session state and is not persistent. Restarting the session may clear records.
- This project is a learning/demo prototype, not a production financial system. It does not connect to bank accounts, file GST returns, calculate statutory tax liability, or provide audit assurance.
- Uploading an invoice image sends it to the configured model provider. Review provider privacy and data-retention terms before using real financial documents.

## Project structure

```text
finance_accounting_management_system/
├── app.py
├── requirements.txt
├── .env.example
├── .gitignore
└── README.md
```
