import os, json, csv, io
from datetime import date
import streamlit as st
import pandas as pd
from dotenv import load_dotenv
from openai import OpenAI

load_dotenv()
st.set_page_config(page_title="LedgerAI | Finance Operations", page_icon="💼", layout="wide")

st.markdown("""
<style>
.stApp {background:#f4f6fa}
[data-testid="stMetric"] {background:white;padding:18px;border:1px solid #e7eaf1;border-radius:13px}
.block-container {padding-top:2rem}
h1,h2,h3 {color:#172033}
</style>
""", unsafe_allow_html=True)

st.title("💼 LedgerAI")
st.caption("Finance & Accounting Management System | GenAI extraction + finance operations automation")

if "transactions" not in st.session_state:
    st.session_state.transactions = [
        {"Date":"2026-10-31","Description":"Client payment received","Category":"Sales","Type":"Income","Amount":24000.0,"Status":"Completed"},
        {"Date":"2026-10-30","Description":"Office supplies","Category":"Office supplies","Type":"Expense","Amount":3250.0,"Status":"Completed"},
        {"Date":"2026-10-28","Description":"Software subscription","Category":"Technology","Type":"Expense","Amount":1499.0,"Status":"Completed"},
        {"Date":"2026-10-26","Description":"Website development","Category":"Services","Type":"Income","Amount":18000.0,"Status":"Completed"},
    ]
if "invoices" not in st.session_state:
    st.session_state.invoices = []

def money(value):
    return f"₹{value:,.2f}"

def get_df():
    return pd.DataFrame(st.session_state.transactions)

def extract_invoice_with_llm(uploaded_file):
    """Extract structured invoice data using an OpenAI-compatible vision model.
    Configure OPENAI_API_KEY and OPENAI_MODEL in .env. PDF support may require
    converting pages to images or using a provider that accepts PDF attachments.
    """
    api_key = os.getenv("OPENAI_API_KEY")
    model = os.getenv("OPENAI_MODEL", "gpt-4o-mini")
    if not api_key:
        raise RuntimeError("OPENAI_API_KEY is not configured. Add it to your .env file.")
    if uploaded_file.type not in ("image/png", "image/jpeg", "image/webp"):
        raise RuntimeError("For this starter project, upload a PNG, JPG or WEBP invoice image for AI extraction.")
    import base64
    encoded = base64.b64encode(uploaded_file.getvalue()).decode("utf-8")
    client = OpenAI(api_key=api_key)
    prompt = """Extract invoice details from this image. Return ONLY valid JSON with keys:
vendor_name, invoice_number, invoice_date, due_date, currency, subtotal, tax, total,
description, category. Use null for missing values. Amounts must be numbers.
Do not guess values that are not visible."""
    response = client.chat.completions.create(
        model=model,
        temperature=0,
        response_format={"type":"json_object"},
        messages=[{"role":"user","content":[
            {"type":"text","text":prompt},
            {"type":"image_url","image_url":{"url":f"data:{uploaded_file.type};base64,{encoded}"}}
        ]}]
    )
    return json.loads(response.choices[0].message.content)

st.sidebar.title("Navigation")
page = st.sidebar.radio("Go to", ["Dashboard", "Transactions", "AI Invoice Extraction", "Reports", "About"])

if page == "Dashboard":
    df = get_df()
    income = df.loc[df.Type=="Income","Amount"].sum() if not df.empty else 0
    expenses = df.loc[df.Type=="Expense","Amount"].sum() if not df.empty else 0
    profit = income-expenses
    st.subheader("Finance overview")
    c1,c2,c3,c4 = st.columns(4)
    c1.metric("Total income", money(income))
    c2.metric("Total expenses", money(expenses))
    c3.metric("Net profit", money(profit), delta=f"{(profit/income*100):.1f}% margin" if income else None)
    c4.metric("Invoices captured", len(st.session_state.invoices))
    left,right = st.columns([1.5,1])
    with left:
        st.markdown("### Income vs expenses")
        if not df.empty:
            chart = df.groupby("Type")["Amount"].sum()
            st.bar_chart(chart)
        else:
            st.info("Add transactions to see your cash-flow summary.")
    with right:
        st.markdown("### Latest activity")
        st.dataframe(df.tail(5).iloc[::-1], use_container_width=True, hide_index=True)
    st.info("Starter data is illustrative. Replace it with your verified business records before operational use.")

elif page == "Transactions":
    st.subheader("Transaction management")
    with st.form("add_transaction", clear_on_submit=True):
        a,b,c = st.columns(3)
        tx_date = a.date_input("Date", value=date.today())
        tx_type = b.selectbox("Type", ["Income","Expense"])
        category = c.selectbox("Category", ["Sales","Services","Operations","Travel","Office supplies","Technology","Other"])
        description = st.text_input("Description")
        amount = st.number_input("Amount (₹)", min_value=0.01, step=100.0)
        submitted = st.form_submit_button("Add transaction", type="primary")
        if submitted:
            if not description.strip():
                st.error("Please enter a description.")
            else:
                st.session_state.transactions.append({"Date":str(tx_date),"Description":description.strip(),"Category":category,"Type":tx_type,"Amount":float(amount),"Status":"Completed"})
                st.success("Transaction added.")
                st.rerun()
    df = get_df()
    search = st.text_input("Search transactions")
    if search:
        df = df[df.astype(str).apply(lambda row: row.str.contains(search,case=False).any(),axis=1)]
    st.dataframe(df, use_container_width=True, hide_index=True)
    if not df.empty:
        csv_data = df.to_csv(index=False).encode("utf-8")
        st.download_button("⬇ Download transactions CSV", csv_data, "ledgerai_transactions.csv", "text/csv")

elif page == "AI Invoice Extraction":
    st.subheader("AI-powered invoice extraction")
    st.write("Upload an invoice image. The configured vision LLM will extract key accounting fields into structured data.")
    uploaded = st.file_uploader("Upload invoice image", type=["png","jpg","jpeg","webp"])
    if uploaded:
        st.image(uploaded, caption=uploaded.name, use_container_width=True)
        if st.button("✨ Extract invoice details", type="primary"):
            with st.spinner("Reading invoice with AI..."):
                try:
                    result = extract_invoice_with_llm(uploaded)
                    st.session_state.latest_extraction = result
                    st.success("Extraction completed. Verify every field before saving.")
                except Exception as exc:
                    st.error(str(exc))
    if "latest_extraction" in st.session_state:
        st.markdown("### Extracted fields — review before saving")
        result = st.session_state.latest_extraction
        edited = {}
        cols = st.columns(2)
        for i,(key,value) in enumerate(result.items()):
            with cols[i%2]:
                edited[key] = st.text_input(key.replace("_"," ").title(), value="" if value is None else str(value), key=f"extract_{key}")
        if st.button("Save invoice record"):
            st.session_state.invoices.append(edited)
            st.success("Invoice record saved in this session.")
            del st.session_state.latest_extraction
            st.rerun()
    st.caption("Privacy: the uploaded image is sent to the LLM provider configured in your environment. Do not upload confidential documents unless your provider and organization policies permit it.")

elif page == "Reports":
    st.subheader("Financial reports")
    df = get_df()
    if df.empty:
        st.info("No transactions available.")
    else:
        summary = df.groupby("Type")["Amount"].sum().reindex(["Income","Expense"],fill_value=0)
        income = float(summary["Income"]); expenses = float(summary["Expense"])
        report = pd.DataFrame([
            {"Metric":"Total income","Amount":income},
            {"Metric":"Total expenses","Amount":expenses},
            {"Metric":"Net profit","Amount":income-expenses},
            {"Metric":"Profit margin (%)","Amount":(income-expenses)/income*100 if income else 0}
        ])
        st.dataframe(report, use_container_width=True, hide_index=True)
        st.bar_chart(summary)
        st.download_button("Download report CSV", report.to_csv(index=False).encode(), "finance_report.csv", "text/csv")
    if st.session_state.invoices:
        st.markdown("### Saved invoices")
        st.dataframe(pd.DataFrame(st.session_state.invoices), use_container_width=True, hide_index=True)

else:
    st.subheader("About this project")
    st.markdown("""
**LedgerAI — Finance & Accounting Management System**

- **GenAI:** Extracts vendor, invoice number, dates, tax and totals from invoice images.
- **Automation:** Adds transactions, calculates income/expenses/profit and exports CSV reports.
- **Agent concept:** A finance operations assistant that turns unstructured invoice documents into reviewable structured records.
- **Stack:** Python, Streamlit, OpenAI-compatible LLM API and pandas.

This is an educational starter project, not production accounting software. It does not connect to banks, submit tax returns, or provide audited financial statements. Data is held in Streamlit session state and resets when the app session ends.
""")
